/*
 * The MIT License
 *
 * Copyright 2016 Juan Jose Hernandez Alonso.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package es.seas.ejemplo.timer.controller;

import es.seas.ejemplo.timer.model.entities.Country;
import es.seas.ejemplo.timer.controller.util.JsfUtil;
import es.seas.ejemplo.timer.controller.util.JsfUtil.PersistAction;
import es.seas.ejemplo.timer.model.entities.daos.CountryFacade;

import java.io.Serializable;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

/**
 * Clase que controla las operaciones CRUD de la entidad pais.
 *
 * @author Juan José Hernández Alonso.
 */
@ManagedBean(name = "countryController")
@SessionScoped
public class CountryController implements Serializable {

    @EJB
    private es.seas.ejemplo.timer.model.entities.daos.CountryFacade ejbFacade;
    private List<Country> items = null;
    private Country selected;

    /**
     * Constructor por defecto.
     */
    public CountryController() {
    }

    /**
     * Getter del elemento seleccionado.
     *
     * @return Country selected.
     */
    public Country getSelected() {
        return selected;
    }

    /**
     * Setter del elemento seleccionado.
     *
     * @param selected Country.
     */
    public void setSelected(Country selected) {
        this.selected = selected;
    }

    /**
     * Método preparado para establecer claves embebidas.
     */
    protected void setEmbeddableKeys() {
    }

    /**
     * Método preparado para inicializar claves embebidas.
     */
    protected void initializeEmbeddableKey() {
    }

    private CountryFacade getFacade() {
        return ejbFacade;
    }

    /**
     * Método que inicializa el elemento seleccionado y prepara el bean para
     * crear un país nuevo.
     *
     * @return Country selected.
     */
    public Country prepareCreate() {
        selected = new Country();
        initializeEmbeddableKey();
        return selected;
    }

    /**
     * Método para crear un nuevo país.
     */
    public void create() {
        persist(PersistAction.CREATE, ResourceBundle.getBundle("/es/seas/"
                + "ejemplo/timer/en_bundle").getString("CountryCreated"));
        if (!JsfUtil.isValidationFailed()) {
            items = null;
        }
    }

    /**
     * Método para actualizar un país.
     */
    public void update() {
        persist(PersistAction.UPDATE, ResourceBundle.getBundle("/es/seas/ejemplo/timer/en_bundle").getString("CountryUpdated"));
    }

    /**
     * Método para eliminar un país.
     */
    public void destroy() {
        persist(PersistAction.DELETE, ResourceBundle.getBundle("/es/seas/ejemplo/timer/en_bundle").getString("CountryDeleted"));
        if (!JsfUtil.isValidationFailed()) {
            selected = null;
            items = null;
        }
    }

    /**
     * Método que inicializa la lista de países si no estaba inicializada para
     * mostrarlos en una tabla o elemento que nos permita listar.
     *
     * @return List de países.
     */
    public List<Country> getItems() {
        if (items == null) {
            items = getFacade().findAll();
        }
        return items;
    }

    private void persist(PersistAction persistAction, String successMessage) {
        if (selected != null) {
            setEmbeddableKeys();
            try {
                if (persistAction != PersistAction.DELETE) {
                    getFacade().edit(selected);
                } else {
                    getFacade().remove(selected);
                }
                JsfUtil.addSuccessMessage(successMessage);
            } catch (EJBException ex) {
                String msg = "";
                Throwable cause = ex.getCause();
                if (cause != null) {
                    msg = cause.getLocalizedMessage();
                }
                if (msg.length() > 0) {
                    JsfUtil.addErrorMessage(msg);
                } else {
                    JsfUtil.addErrorMessage(ex, ResourceBundle.getBundle("/es/seas/ejemplo/timer/en_bundle").getString("PersistenceErrorOccured"));
                }
            } catch (Exception ex) {
                Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
                JsfUtil.addErrorMessage(ex, ResourceBundle.getBundle("/es/seas/ejemplo/timer/en_bundle").getString("PersistenceErrorOccured"));
            }
        }
    }

    /**
     * Método que se llama para cargar países en un componente de selección
     * múltiple.
     *
     * @return List de países.
     */
    public List<Country> getItemsAvailableSelectMany() {
        return getFacade().findAll();
    }

    /**
     * Método que se llama para cargar países en un componente de selección
     * simple.
     *
     * @return List de países.
     */
    public List<Country> getItemsAvailableSelectOne() {
        return getFacade().findAll();
    }

    /**
     * Conversor de cadena a objeto y viceversa de objetos país.
     */
    @FacesConverter(forClass = Country.class)
    public static class CountryControllerConverter implements Converter {

        /**
         * Método que convierte la representación en una cadena a un objeto.
         *
         * @param facesContext contexto.
         * @param component componente.
         * @param value valor a convertir.
         * @return Object objeto recuperado a través de su id.
         */
        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            CountryController controller = (CountryController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "countryController");
            return controller.getFacade().find(getKey(value));
        }

        java.lang.String getKey(String value) {
            java.lang.String key;
            key = value;
            return key;
        }

        String getStringKey(java.lang.String value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value);
            return sb.toString();
        }

        /**
         * Método que convierte un objeto en su representación como cadena.
         *
         * @param facesContext contexto.
         * @param component componente.
         * @param object valor a convertir.
         * @return String objeto como cadena.
         */
        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof Country) {
                Country o = (Country) object;
                return getStringKey(o.getCode());
            } else {
                Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "object {0} is of type {1}; expected type: {2}", new Object[]{object, object.getClass().getName(), Country.class.getName()});
                return null;
            }
        }

    }

}
