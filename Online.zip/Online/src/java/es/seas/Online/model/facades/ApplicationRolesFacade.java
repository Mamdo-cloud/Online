/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.seas.Online.model.facades;

import es.seas.Online.model.entities.ApplicationRoles;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author GJHN4872
 */
@Stateless
public class ApplicationRolesFacade extends AbstractFacade<ApplicationRoles> {

    @PersistenceContext(unitName = "OnlinePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ApplicationRolesFacade() {
        super(ApplicationRoles.class);
    }
    
}
