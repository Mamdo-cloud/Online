/*
 * The MIT License
 *
 * Copyright 2015 SEAS - Estudios Abiertos.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package es.seas.ejemplo.filtros.login.controller;

import es.seas.ejemplo.filtros.login.model.UserBean;
import java.awt.event.ActionEvent;
import java.io.IOException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

/**
 * Clase donde se realiza el proceso de autentificaci�n. Tendr� un par de campos
 * para las credenciales y otro para el mensaje en caso de error.
 *
 * @author Juan Jos� Hern�ndez Alonso.
 */
@ManagedBean
@SessionScoped
public class AuthBean {

    public final static String USER_KEY = "auth_user";

    private String user;
    private String password;
    private String message;

    /**
     * Constructor por defecto.
     */
    public AuthBean() {
    }

    /**
     * Getter del usuario.
     *
     * @return String user.
     */
    public String getUser() {
        return user;
    }

    /**
     * Setter del usuario.
     *
     * @param user String.
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * Getter del password.
     *
     * @return String password.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Setter del password.
     *
     * @param password String.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Getter del mensaje.
     * @return String message.
     */
    public String getMessage() {
        return message;
    }

    /**
     * Setter del mensaje.
     * @param message String.
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * M�todo que comprueba las credenciales y redirige a uno u otro sitio
     * dependiendo del resultado.
     * @param e Evento que ha disparado este m�todo.
     * @throws IOException Excepci�n de escritura o lectura.
     */
    public void doLogin(ActionEvent e) throws IOException {
        FacesContext context = FacesContext.getCurrentInstance();
        ExternalContext extContext = context.getExternalContext();
        String url;
        if (isAdmin(user, password)) {
            url = extContext.encodeActionURL(
                    context.getApplication().getViewHandler().getActionURL(
                            context, "/administrator/AdminIndex.xhtml"));
            extContext.getSessionMap().put(USER_KEY, new UserBean(user, "admin"));
            extContext.redirect(url);
            return;

        }
        if (isUser(user, password)) {
            url = extContext.encodeActionURL(
                    context.getApplication().getViewHandler().getActionURL(
                            context, "/user/UserIndex.xhtml"));
            extContext.getSessionMap().put(USER_KEY, new UserBean(user, "user"));
            extContext.redirect(url);
            return;
        }
        message = "Usuario y/o clave inv�lida";
    }

    /**
     * M�todo que nos dir� si un usuario es administrador o no. En este caso,
     * solo lo ser� si el usuario y el password son "admin".
     * @param user String usuario.
     * @param password String password.
     * @return boolean true si ambos par�metros tienen el valor de "admin".
     */
    private boolean isAdmin(String user, String password) {
        return user.equals("admin") && password.equals("admin");
        //Aqui se puede validar hacia una base de datos
    }

    /**
     * M�todo que nos dir� si un usuario es usuario normal o no. En este caso,
     * solo lo ser� si el usuario y el password son "user".
     * @param user String usuario.
     * @param password String password.
     * @return boolean true si ambos par�metros tienen el valor de "user".
     */
    private boolean isUser(String user, String password) {
        return user.equals("user") && password.equals("user");
        //Aqui se puede validar hacia una base de datos
    }

    /**
     * Si el usuario est� logueado, recuperamos el nombre del mismo de la 
     * sesi�n.
     * @return String nombre de usuario.
     */
    public String getLoggedUserName() {
        return ((UserBean) FacesContext.getCurrentInstance().
                getExternalContext().getSessionMap().get(USER_KEY)).toString();
    }

    /**
     * M�todo para desloguearnos que elimina de la sesi�n el usuario y redirige
     * al index.
     * @throws IOException
     */
    public void logout() throws IOException {
        FacesContext context = FacesContext.getCurrentInstance();
        ExternalContext extContext = context.getExternalContext();
        extContext.getSessionMap().remove(USER_KEY);
        String url = extContext.encodeActionURL(
                context.getApplication().getViewHandler().getActionURL(
                        context, "/index.jspx"));
        extContext.redirect(url);
    }

}
