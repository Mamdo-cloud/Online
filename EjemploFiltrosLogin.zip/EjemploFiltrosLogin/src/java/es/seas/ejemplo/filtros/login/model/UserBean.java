/*
 * The MIT License
 *
 * Copyright 2015 SEAS - Estudios Abiertos.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package es.seas.ejemplo.filtros.login.model;

import java.io.Serializable;

/**
 * Clase que representa un usuario. Este tendr� un rol para el acceso y un
 * nombre de usuario.
 *
 * @author Juan Jos� Hern�ndez Alonso.
 */
public class UserBean implements Serializable {

    private String user;
    private String role;

    /**
     * Constructor por defecto.
     */
    public UserBean() {
    }

    /**
     * Constructor parametrizado.
     *
     * @param user String nombre de usuario.
     * @param role String nombre del rol (admin/user).
     */
    public UserBean(String user, String role) {
        this.user = user;
        this.role = role;
    }

    /**
     * Getter del nombre de usuario.
     * @return String user.
     */
    public String getUser() {
        return user;
    }

    /**
     * Setter del nombre de usuario.
     * @param user String.
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * Getter del nombre del rol.
     * 
     * @return String role.
     */
    public String getRole() {
        return role;
    }

    /**
     * Setter del nombre del rol.
     * @param role String.
     */
    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return user;
    }

}
